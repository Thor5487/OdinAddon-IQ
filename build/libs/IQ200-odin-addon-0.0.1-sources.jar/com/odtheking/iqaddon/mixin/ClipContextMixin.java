package com.odtheking.iqaddon.mixin;

import com.odtheking.iqaddon.features.impl.skyblock.FullBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3959.class)
public class ClipContextMixin {

    // 攔截視線追蹤獲取形狀的瞬間
    @Inject(method = "getBlockShape(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/phys/shapes/VoxelShape;", at = @At("RETURN"), cancellable = true)
    private void iqaddon$injectBlockShape(class_2680 state, class_1922 level, class_2338 pos, CallbackInfoReturnable<class_265> cir) {
        // 呼叫你的 Kotlin 程式碼
        class_265 outline = FullBlock.INSTANCE.getShape(state);

        // 如果你的功能有開啟且判斷是玻璃窗，就會取代原本的形狀
        if (outline != null) {
            cir.setReturnValue(outline);
        }
    }
}